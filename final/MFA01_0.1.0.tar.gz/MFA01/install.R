install.packages(c("devtools", "roxygen2", "testthat", "knitr"))

install.packages('MGA01')
library(devtools)
# creating documentation (i.e. the Rd files in man/)
devtools::document()
# checking documentation
devtools::check_man()
# building tarball (e.g. oski_0.1.tar.gz)
devtools::build()
# checking install
devtools::install()
