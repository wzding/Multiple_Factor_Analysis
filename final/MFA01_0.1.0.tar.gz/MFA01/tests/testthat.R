library(testthat)
library(MFA01)

test_check("MFA01")
